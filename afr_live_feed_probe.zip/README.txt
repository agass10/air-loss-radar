AFR live-feed feasibility test (experimental)

This is a standalone Streamlit page, not an incident detector.

To test with your existing app:
1. In your GitHub repo create a folder named pages (if it doesn't exist).
2. Upload pages/01_Live_Feed_Test.py into that folder.
3. Commit. Streamlit should add a page called Live Feed Test.
4. Open that page and click Test NYC dispatch metadata connection once.
5. Send the results screenshot.

No other files need replacement. No payments, credentials, emails, or continuous polling.
The OpenMHz production API and NYC feed are UNVERIFIED; errors are a valid test result.
Do not use this to claim real-time detection or address identification.
